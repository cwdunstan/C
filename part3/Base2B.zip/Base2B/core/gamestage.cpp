#include "gamestage.h"

GameStage::~GameStage() {

}

void GameStage::update() {

}

void GameStage::render(Renderer &renderer) {

}

void GameStage::input(QKeyEvent &event) {

}
